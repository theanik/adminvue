const values = {
    BASE_URL : 'http://68.183.157.25:4000'
    // BASE_URL : 'http://localhost:4000'
}

export default values;