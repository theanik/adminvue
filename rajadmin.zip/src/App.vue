<template>
  <div id="app">
    <vue-snotify></vue-snotify>
    <notifications></notifications>
    <router-view/>
  </div>
</template>
